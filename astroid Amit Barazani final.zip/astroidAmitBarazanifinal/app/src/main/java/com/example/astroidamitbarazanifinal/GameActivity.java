package com.example.astroidamitbarazanifinal;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class GameActivity extends AppCompatActivity {
    DrawSurfaceView ds;
    Thread thread;
    FrameLayout frame;
    int coinCount = 0;
    Button up, down, right, left;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        frame = findViewById(R.id.frame);
        ds = new DrawSurfaceView(this);
        frame.addView(ds);
        thread = new Thread(ds);
        thread.start();

        right = findViewById(R.id.btnR);
        right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ds.moveR();
            }
        });
        left = findViewById(R.id.btnL);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ds.moveL();
            }
        });
        up = findViewById(R.id.btnU);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ds.moveU();
            }
        });
        down = findViewById(R.id.btnD);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ds.moveD();
            }
        });
    }


    public void pauseResume(View view)
    {
        //TODO
    }

    public void playResume(View view)
    {
        //TODO
    }
    public void move(View view)
    {

    }
}
