package com.example.astroidamitbarazanifinal;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.Random;


public class DrawSurfaceView extends SurfaceView implements Runnable {
    int interval=50;//try to change it
    float dx=20;
    float dy=20;
    Context context;
    SurfaceHolder holder;
    boolean threadRunning = true;
    boolean isRunning = true;
    Bitmap bitmap;
    Bitmap coin;
    float x =100;
    float y =100;
    int coinCount = 0;
    int xCoin;  int yCoin;
    Random random = new Random();

    public DrawSurfaceView(Context context)
    {
        super(context);
        this.context = context;
        holder = getHolder();
        bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.astro4);
        coin = BitmapFactory.decodeResource(getResources(), R.drawable.coin);

        xCoin = random.nextInt(400);
        yCoin = random.nextInt(400);

    }

    @Override
    public void run() {
        while (threadRunning)
        {
            if(isRunning)
            {
                if(!holder.getSurface().isValid())
                    continue;

                Canvas c = null;
                try
                {
                    c = this.getHolder().lockCanvas();//what with line meaning?
                    synchronized (this.getHolder()){
                        checkCoin();
                        c.drawRGB(100,100,255);//Try pushing this line into a remark. what happened? you can change the color.
                        c.drawBitmap(bitmap,x,y,null);
                        automaticMove();
                        c.drawBitmap(coin,xCoin,yCoin,null);
                    }
                    Thread.sleep(interval);
                }
                catch (Exception e)
                {

                }
                /*what is finally?
                 */
                finally {
                    if(c!=null)
                    {
                        this.getHolder().unlockCanvasAndPost(c);//what this line meaning?
                    }
                }
            }
        }
    }

    public void checkCoin(){

            if(x > xCoin - 10 && x < xCoin + 10 && y > yCoin - 10 && y < yCoin + 10){
                coinCount = coinCount + 1;

                xCoin = random.nextInt(this.getWidth());
                yCoin = random.nextInt(this.getHeight());
            }


        if(coinCount==10){
            Intent intent = new Intent(this.getContext(),Win.class);
            this.getContext().startActivity(intent);
        }
    }

    /*
    how it works?
     */
    public void automaticMove()
    {
        x = x + dx;
        y = y + dy;
        if(x < 0 || x > this.getWidth())
            dx = -dx;
        if(y < 0 || y > this.getHeight())
            dy = -dy;
    }
    public void moveD()
    {
        y = y - dy;
        if(y < 0 || y > this.getHeight())
            dy = -dy;
    }
    public void moveU()
    {
        y = y + dy;
        if(y < 0 || y > this.getHeight())
            dy = -dy;
    }
    public void moveL()
    {
        x = x - dx;
        if(x < 0 || x > this.getWidth())
            dx = -dx;
    }
    public void moveR()
    {
        x = x + dx;
        if(x < 0 || x > this.getWidth())
            dx = -dx;
    }

}


